package by.htp.lesson.main;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("by.htp.lesson.main")
public class SportConfig {
	
}
