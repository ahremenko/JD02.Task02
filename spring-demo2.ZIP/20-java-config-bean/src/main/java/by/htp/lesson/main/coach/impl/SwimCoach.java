package by.htp.lesson.main.coach.impl;

import by.htp.lesson.main.coach.Coach;
import by.htp.lesson.main.fortune_service.FortuneService;

public class SwimCoach implements Coach {

	private FortuneService fortuneService;

	public SwimCoach(FortuneService theFortuneService) {
		fortuneService = theFortuneService;
	}
	
	
	public String getDailyWorkout() {
		return "Swim 1000 meters as a warm up.";
	}

	
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}

}




