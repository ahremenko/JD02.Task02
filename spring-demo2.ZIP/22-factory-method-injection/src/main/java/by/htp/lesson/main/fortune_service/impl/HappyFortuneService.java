package by.htp.lesson.main.fortune_service.impl;

import by.htp.lesson.main.fortune_service.FortuneService;

public class HappyFortuneService implements FortuneService {
	
	private HappyFortuneService(){}

	
	public static FortuneService getFortuneService(){
		return new HappyFortuneService();
	}
	
	public String getFortune() {
		return "Today is your lucky day!";
	}

}
