package by.htp.lesson.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import by.htp.lesson.main.coach.impl.CricketCoach;
import by.htp.lesson.main.coach.impl.TrackCoach;

public class DemoApp {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
	
		TrackCoach theCoach1 = context.getBean("myCoach", TrackCoach.class);
		TrackCoach theCoach2 = context.getBean("myCoach", TrackCoach.class);
		
		System.out.println(theCoach1 == theCoach2);
		
		context.close();
	}
}






