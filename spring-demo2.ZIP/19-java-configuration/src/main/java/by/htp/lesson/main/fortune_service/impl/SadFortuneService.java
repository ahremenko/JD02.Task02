package by.htp.lesson.main.fortune_service.impl;

import by.htp.lesson.main.fortune_service.FortuneService;

public class SadFortuneService implements FortuneService {


	public String getFortune() {
		return "Today is a sad day";
	}

}
