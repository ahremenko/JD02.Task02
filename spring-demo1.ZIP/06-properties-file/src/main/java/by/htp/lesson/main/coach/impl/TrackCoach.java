package by.htp.lesson.main.coach.impl;

import by.htp.lesson.main.coach.Coach;
import by.htp.lesson.main.fortune_service.FortuneService;

public class TrackCoach implements Coach {

	private FortuneService fortuneService;

	public TrackCoach() {
		
	}
	
	public TrackCoach(FortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}

	
	public String getDailyWorkout() {
		return "Run a hard 5k";
	}

	
	public String getDailyFortune() {
		return "Just Do It: " + fortuneService.getFortune();
	}

}










