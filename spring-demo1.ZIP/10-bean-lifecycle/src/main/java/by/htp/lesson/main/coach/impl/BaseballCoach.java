package by.htp.lesson.main.coach.impl;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import by.htp.lesson.main.coach.Coach;
import by.htp.lesson.main.fortune_service.FortuneService;

public class BaseballCoach implements Coach, BeanNameAware, BeanFactoryAware {

	private FortuneService fortuneService;

	public BaseballCoach(FortuneService theFortuneService) {
		fortuneService = theFortuneService;
	}

	
	public String getDailyWorkout() {
		return "Spend 30 minutes on batting practice";
	}

	
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}


	public void setBeanName(String arg0) {
		System.out.println(" -- Inside BeanNameAware.setBeanName, arg0=" + arg0);
		
	}


	public void setBeanFactory(BeanFactory arg0) throws BeansException {
		System.out.println(" -- Inside BeanFactoryAware.setBeanFactory, arg0(class name)=" + arg0.getClass().getSimpleName());
		
	}

}
