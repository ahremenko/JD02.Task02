package by.htp.lesson.main.fortune_service;

public interface FortuneService {

	public String getFortune();
	
}
