package by.htp.lesson.main.coach.impl;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;

import by.htp.lesson.main.coach.Coach;
import by.htp.lesson.main.fortune_service.FortuneService;

public class BaseballCoach implements Coach {

	private FortuneService fortuneService;

	public BaseballCoach(FortuneService theFortuneService) {
		fortuneService = theFortuneService;
	}

	
	public String getDailyWorkout() {
		return "Spend 30 minutes on batting practice";
	}

	
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}


}
