package by.htp.lesson.main;

public interface FortuneService {

	public String getFortune();
	
}
