package by.htp.lesson.main.fortune_service.impl;

import org.springframework.stereotype.Component;

import by.htp.lesson.main.fortune_service.FortuneService;


@Component
public class RESTFortuneService implements FortuneService {

	public String getFortune() {
		return "REST service message";
	}

}
