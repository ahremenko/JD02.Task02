package by.htp.lesson.main;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import by.htp.lesson.main.coach.Coach;
import by.htp.lesson.main.coach.impl.SwimCoach;
import by.htp.lesson.main.fortune_service.FortuneService;
import by.htp.lesson.main.fortune_service.impl.SadFortuneService;

@Configuration
public class SportConfig {
	
	@Bean
	public FortuneService sadFortuneService() {
		return new SadFortuneService();
	}
	
	@Bean
	public Coach swimCoach() {
		SwimCoach mySwimCoach = new SwimCoach(sadFortuneService());
		
		return mySwimCoach;
	}
	
}








