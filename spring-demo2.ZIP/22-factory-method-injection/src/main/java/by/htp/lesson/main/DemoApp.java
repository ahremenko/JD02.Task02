package by.htp.lesson.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import by.htp.lesson.main.coach.impl.BaseballCoach;
import by.htp.lesson.main.coach.impl.CricketCoach;

public class DemoApp {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
	
		CricketCoach theCoach = context.getBean("myCricketCoach", CricketCoach.class);
		
		System.out.println(theCoach.getDailyWorkout());
		
		System.out.println(theCoach.getDailyFortune());
		
		System.out.println(theCoach.getEmailAddress());
		
		System.out.println(theCoach.getTeam());
		
		BaseballCoach coach1 = context.getBean("myCoach", BaseballCoach.class);

		BaseballCoach coach2 = context.getBean("myCoach2", BaseballCoach.class);
		
		System.out.println(coach1.getDailyFortune());

		System.out.println(coach2.getDailyFortune());

		context.close();
	}

}






