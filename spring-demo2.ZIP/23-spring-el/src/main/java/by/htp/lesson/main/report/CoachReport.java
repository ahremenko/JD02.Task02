package by.htp.lesson.main.report;

public class CoachReport {
	
	private String email;
	private Integer salary;
	
	public CoachReport(){}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	
	
	

}
