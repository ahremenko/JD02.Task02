package by.htp.lesson.main;

public interface Coach {
	
	public String getDailyWorkout();

	public String getDailyFortune();

}
