package by.htp.lesson.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import by.htp.lesson.main.coach.impl.CricketCoach;
import by.htp.lesson.main.report.CoachReport;

public class DemoApp {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
	
		CricketCoach theCoach = context.getBean("myCricketCoach", CricketCoach.class);
		
		CoachReport report = context.getBean("myCricketCoachReport", CoachReport.class);
		
		System.out.println(theCoach.getEmailAddress());
		
		System.out.println(report.getEmail());
		
		System.out.println(report.getSalary());
		

		context.close();
	}

}






