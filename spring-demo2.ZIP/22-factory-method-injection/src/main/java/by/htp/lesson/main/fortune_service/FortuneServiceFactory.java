package by.htp.lesson.main.fortune_service;

import by.htp.lesson.main.fortune_service.impl.RandomFortuneService;

public class FortuneServiceFactory {
	
	public FortuneService getRandomFotruneService(){
		return new RandomFortuneService();		
	}

}
