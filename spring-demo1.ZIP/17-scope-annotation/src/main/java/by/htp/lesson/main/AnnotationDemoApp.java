package by.htp.lesson.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import by.htp.lesson.main.coach.Coach;

public class AnnotationDemoApp {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		Coach theCoach1 = context.getBean("tennisCoach", Coach.class);
		Coach theCoach2 = context.getBean("tennisCoach", Coach.class);

		System.out.println(theCoach1 == theCoach2);

		Coach theCoach3 = context.getBean("baseballCoach", Coach.class);
		Coach theCoach4 = context.getBean("baseballCoach", Coach.class);

		System.out.println(theCoach3 == theCoach4);
		
		context.close();
	}

}
