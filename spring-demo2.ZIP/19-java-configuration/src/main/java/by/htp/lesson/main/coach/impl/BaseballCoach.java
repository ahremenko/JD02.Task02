package by.htp.lesson.main.coach.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import by.htp.lesson.main.coach.Coach;
import by.htp.lesson.main.fortune_service.FortuneService;

@Component
@Scope("singleton")
public class BaseballCoach implements Coach {

	private FortuneService fortuneService;

	public BaseballCoach() {
	}
	
	@Autowired
	@Qualifier("RESTFortuneService")
	public void setFortuneService(FortuneService theFortuneService) {
		System.out.println(">> TennisCoach: inside setFortuneService() method");
		this.fortuneService = theFortuneService;
	}

	
	public String getDailyWorkout() {
		return "Spend 30 minutes on batting practice";
	}

	
	public String getDailyFortune() {
		return fortuneService.getFortune();
	}


}
