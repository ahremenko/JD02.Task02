package by.htp.lesson.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import by.htp.lesson.main.coach.impl.CricketCoach;

public class DemoApp {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
	
		CricketCoach theCoach1 = context.getBean("myCricketCoach", CricketCoach.class);
		CricketCoach theCoach2 = context.getBean("myCricketCoach", CricketCoach.class);
		
		System.out.println(theCoach1 == theCoach2);
		System.out.println(theCoach1.getFortuneService() == theCoach2.getFortuneService());
		
		context.close();
	}
}






